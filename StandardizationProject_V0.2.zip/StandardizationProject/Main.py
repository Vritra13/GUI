# Data Standardization
# By Tallen Smith with help from Zach Holden, Adom Simpey, and Hassan Abdulkareem, student at CSUPueblo
# 06/04/19

# Imports necessary libraries
import tkinter as tk
from PIL import Image, ImageTk
import tkinter.filedialog


# Creates a class to hold all the frame information
class App(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)
        # Isn't currently used
        self.IsLoaded = False
        # This setting will turn the outputted image greyscale
        self.IsGreyscale = False
        self.pack()
        # This is the title of the window
        self.master.title("Data Standardization")
        # This is the primary background color of the window
        self.master.tk_setPalette(background="#4d4d4d")
        # Windows have big spacing issues to think about when they get resized... so I don't let them be resized
        self.master.resizable(False, False)
        # The iconbitmap is the small image in the top left of the window
        self.master.iconbitmap('Wolf.ico')
        # This variable will house the loaded image
        self.loadedImage = 'none'

        # Frames to put the widgets into. Run the program to see where they are, since they're labeled currently
        ImageFrame = tk.Frame(self)
        ImageFrame.pack(side='left', padx=25)
        ProcessedFrame = tk.Frame(self)
        ProcessedFrame.pack(side='right')
        OptionsFrame = tk.Frame(ImageFrame)
        OptionsFrame.pack(side='bottom', pady=10)
        SelectFrame = tk.Frame(ProcessedFrame, height=2)
        SelectFrame.pack(side='top', padx=25)

        # This is where I labeled all the frames. We can delete this in the final product
        tk.Label(ImageFrame, text='This is the Image Frame').pack()
        tk.Label(ProcessedFrame, text='This is the Processed Frame').pack()
        tk.Label(OptionsFrame, text='This is the Options Frame').pack()
        tk.Label(SelectFrame, text='This is the Select Frame').grid(row=0, column=0, columnspan=2)

        # These are the variables to create the canvas where the image will be loaded onto
        canvasHeight = 1080 / 2
        canvasWidth = 1920 / 2
        self.canvas = tk.Canvas(ImageFrame, width=canvasWidth, height=canvasHeight, bg='white')
        self.canvas.pack()

        # This is where I create all the buttons on the screen
        tk.Button(OptionsFrame, text='Load Image', command=self.Load_Image, bg='#6C6C6C', fg='white').pack(side='left',
                                                                                                           padx=10)
        tk.Button(OptionsFrame, text='Save Images', command=self.Save_Images, bg='#6C6C6C', fg='white').pack(
            side='right', padx=10)

        tk.Button(SelectFrame, text='Select All', command=self.Select_All, bg='#6C6C6C', fg='white').grid(row=1,
                                                                                                          column=0)
        tk.Button(SelectFrame, text='Delete Selected', command=self.Delete_Selected, bg='#6C6C6C', fg='white').grid(
            row=1, column=1)

        # This is for the options widgets at the bottom of the page
        # This checkbutton will determine if the output is greyscale or not
        tk.Checkbutton(OptionsFrame, text='Greyscale', variable=self.IsGreyscale).pack(side='left', padx=30)
        # This creates the slider that will determine the size of the square that each image will be
        self.resolution = tk.Scale(OptionsFrame, from_=10, to=500, orient='horizontal')
        self.resolution.pack()
        # This sets the default size to be 125x125
        self.resolution.set(125)

        # This loads up my 'No Image' picture onto the canvas. Just a placeholder.
        noImage = ImageTk.PhotoImage(Image.open('NoImage.png'))
        # This self object is required to prevent tkinter from deleting the picture in a trash roundup
        self.noImage = noImage
        self.canvas.create_image(0, 0, anchor='nw', image=self.noImage)

    # These functions control what all the buttons do
    # PyCharm likes to complain because I like do write my functions Like_This
    def Load_Image(self):
        # Troubleshooting dialog
        print('Loading Up Images!')
        # Removes the previously loaded images
        self.canvas.delete('all')
        # Opens up a dialog path where you can find the image you wish to load.
        loadedImage = ImageTk.PhotoImage(Image.open(tk.filedialog.askopenfilename()))
        self.loadedImage = loadedImage
        self.canvas.create_image(0, 0, anchor='nw', image=self.loadedImage)
        # I still don't currently use this variable. Idk. Could be useful.
        self.IsLoaded = True

    def Save_Images(self):
        print('Saving Those Images!')

    def Select_All(self):
        print('Selecting All!')

    def Delete_Selected(self):
        print('Delete Selected!')


# I genuinely don't know what this does tbh. But it works so.
if __name__ == '__main__':
    # Uh... create a new window class named root
    root = tk.Tk()
    # Then... make an App with root in it?
    app = App(root)
    # This one runs the mainloop of the app! I know that one. This is what draws the window.
    app.mainloop()
